---
name: khidr-motion-graphics
description: Make professional vertical motion graphics reels (9:16) from a script or voice-over, as HTML + GSAP rendered to MP4 with HyperFrames, with first-class Arabic kinetic typography. Use when the user asks for a motion graphics reel, an animated explainer, kinetic text, a "موشن جرافيك", "ريل موشن", "اعملي موشن", an animated ad, or wants After Effects-style motion without After Effects.
---

# Khidr Motion Graphics

A working method for 15–60 s vertical motion graphics that look agency-made. It was built from real
client work (charities, platforms, brands) and from studying the reels that perform best in Arabic.

The output is an HTML composition rendered frame by frame to MP4 with HyperFrames
(`npx hyperframes`), so every render is identical and every edit is text.

A ready project lives in `template/` (a 24 s reel: hook → problem → steps → proof → CTA). Copy it,
change the copy and colors, and render.

## 1. Before animating: the beat sheet

Never start with motion. Start with a table, one row per beat (2–4 s each):

| # | time | spoken line | on-screen headline (≤ 4 words) | visual | sound |
|---|------|-------------|--------------------------------|--------|-------|

Rules:
- **Beat 1 is the thumbnail.** Frame 0 already shows the hook headline and the main visual. Never a
  logo, never black, never a slow fade-in.
- **One idea per beat.** If a beat needs two headlines, it is two beats.
- **Headline ≠ subtitle.** The headline is the 2–4 word punch of the line, not the full sentence.
  One word in the headline carries the accent color.
- **End on a CTA card** that holds for ≥ 2 s (name, promise, follow button, link).
- Total length: 20–35 s for social; the payoff lands before second 25.

## 2. Canvas, safe zones, layout

- 1080×1920, 30 fps.
- Nothing readable above y=168 (app status/search bar) or below y=1330 (caption, handle, buttons).
  Keep the right edge clear of the action rail.
- Fixed structure per beat: **headline zone** (y≈210–410) + **stage** (y≈440–1320). The eye learns
  where to look; only the stage content changes.
- One subject per beat, centered. Rebuild landscape ideas as vertical stacks.
- Minimum text size 28 px; headlines 84–96 px; numbers 120 px+.

## 3. Motion language (what makes it look expensive)

**Easing**
- Entrances: `power3.out` / `expo.out` (fast start, soft landing). Exits: `power2.in`, shorter.
- Pops (badges, icons, buttons): `back.out(1.7)`, 0.4–0.5 s.
- Never `linear` except for progress bars, counters' drivers, and continuous rotation.

**Timing**
- Entrance 0.35–0.6 s, exit 0.2–0.3 s. Exits are always shorter than entrances.
- Stagger groups by 0.06–0.12 s. More than 0.15 s feels slow.
- Leave each finished state on screen ≥ 0.8 s before it leaves; text needs ~0.25 s per word to be read.
- Cut to the next beat on the spoken word, not on the round second.

**Moves that carry a reel**
- *Push-in*: the stage scales 1.06 → 1.0 over the whole beat (subtle life on static frames).
- *Typewriter in a chat card*: reveal with `clip-path: inset(...)` animating, from the right for Arabic.
- *Counter*: tween a plain object `{n:0}` to the target with `power2.out` and write `Math.round(n)`.
- *Strike-through*: a 26 px red bar `scaleX 0→1` from the reading start, 0.3 s `power4.out`, then a
  small `rotation` wobble on the struck element.
- *Wipe transition*: two stacked panels sliding `xPercent 100→0`, 0.5 s `power3.inOut`, 0.6 s apart.
- *Waveform*: 20–30 bars with `scaleY` keyframes, staggered from the center (finite repeats only).
- *Badges that float*: ±10 px `y` loop on a 6 s cycle (finite, or tied to the timeline length).

**Rhythm check:** scrub the timeline at 1-second steps. If two consecutive seconds look the same,
something is missing; if three things move at once, remove one.

## 4. Arabic kinetic typography

- `dir="rtl"` on the root. Reveals that "write" text go **right → left**.
- Use a font that has full Arabic shaping and weights: Alexandria (in the template, OFL),
  El Messiri, IBM Plex Sans Arabic, Cairo. Load it with `@font-face` from a local file.
- **No tatweel tricks with Latin words** in display fonts: write `بـ Claude` with a space, or
  rephrase (`بالذكاء الاصطناعي`). Mixed bidi like `بالـAI` breaks in many display fonts.
- `white-space: nowrap` on the accented word so the underline never splits across lines.
- Accent = color + a 10 px rounded underline under the word, not bold alone.
- Line length ≤ 4–5 words for headlines. Break lines by meaning, never leave one short word alone.
- Numbers inside Arabic text stay Western digits for readability in reels (`48 ساعة`).

## 5. Color and look

- 1 background family, 1 ink, 1 accent, 1 highlight. Example (template): green `#00a64f`
  background, ink `#08110d`, accent teal `#3dd6d0`, highlight `#f5e79a`.
- Cards: dark ink with a 1–3 px accent border at 50% opacity, 36–48 px radius, big soft shadow.
- Add a 6 px dot grain at 8% opacity over flat backgrounds; it removes the "digital flat" feel.
- Contrast: every text/background pair ≥ 3:1 (headlines) and ≥ 4.5:1 (body).

## 6. Sound

- Voice-over first, then motion is retimed to the voice (see §7).
- One SFX per visible action, never per word: whoosh on transitions, pop on badges, impact on the
  hook, soft swell before the CTA. Volumes 0.2–0.35 under voice.
- Loudness of the final mix around −14 LUFS for social. Use only CC0 or licensed sounds
  (the `template/assets/sfx` set is CC0, see its license file).

## 7. Retiming to a voice-over

1. Get the voice file. Detect pauses: `ffmpeg -i voice.mp3 -af silencedetect=n=-35dB:d=0.22 -f null -`.
2. Map each pause to the end of a sentence → new beat starts.
3. Build the timeline on a *draft clock* (comfortable round times), then map each beat's slice onto
   its voice slot with `tl.tweenFromTo(oldStart, oldEnd, {duration: newDur, ease: "none"})` added to a
   master timeline at the new start. The template's `story.html` does exactly this (`OLD`/`NEW` arrays).
4. Move clip `data-start` / `data-duration` to the new values; move SFX to the new beat starts.

## 8. HyperFrames contract (summary)

- Every timed element: `class="clip"`, `data-start`, `data-duration`.
- One paused GSAP timeline per composition, registered on `window.__timelines["<id>"]`.
- No `Date.now()`, unseeded randomness, timers, network fetches or `repeat: -1`.
- Don't tween `display`/`visibility` on a clip; animate a child.
- Run `npx hyperframes check --json` and fix every error; then `npx hyperframes snapshot --at ...`
  and look at the frames before `npx hyperframes render -o out/reel.mp4`.

## 9. Review before delivery (tough-client pass)

- [ ] Frame 0 works as a thumbnail with the sound off.
- [ ] Every headline is readable in its time on screen (≈0.25 s per word + 0.5 s).
- [ ] No orphan words, no broken bidi, no text in the unsafe zones.
- [ ] Each beat has exactly one main motion; transitions are under 0.6 s.
- [ ] Counters land on their final number before the beat ends.
- [ ] CTA holds ≥ 2 s; the last frame is a clean still.
- [ ] Mix ≈ −14 LUFS, voice clearly above music and SFX.
- [ ] Rendered 1080×1920, H.264, `+faststart`.

## Quick start

```bash
cp -r template my-reel && cd my-reel
# edit compositions/story.html (copy, colors) and index.html (voice, SFX times)
npx hyperframes check --json
npx hyperframes render -o out/my-reel.mp4
```

Made by Mohamed Khidr (Khidr AI) — motion graphics animator & AI video.
